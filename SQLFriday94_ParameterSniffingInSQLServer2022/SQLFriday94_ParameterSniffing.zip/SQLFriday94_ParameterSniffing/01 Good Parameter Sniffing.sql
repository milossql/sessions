/****************************************************************************/
/*                  SQL Friday #94, 4th November 2022                       */
/*                  Author: Milos Radivojevic                               */
/*           Session: Parametr Sniffing in SLQ Server 2022                  */
/****************************************************************************/
/*                      Good Parameter Sniffing                             */
/*                                                                          */
/****************************************************************************/

USE TSQLTips;
GO
CREATE OR ALTER PROCEDURE dbo.GetEventsSince
@Date DATE
AS
BEGIN
	SELECT * FROM dbo.Events
	WHERE EventDate >= @Date
END
GO

CREATE OR ALTER PROCEDURE dbo.GetEventsSince2
@Date DATE
AS
BEGIN
	SELECT * FROM dbo.Events
	WHERE EventDate >= @Date
	OPTION (USE HINT ('DISABLE_PARAMETER_SNIFFING'));
END
GO

SET STATISTICS IO, TIME ON;

DECLARE @d DATE = GETDATE();
EXEC dbo.GetEventsSince @d;
GO
DECLARE @d DATE = GETDATE();
EXEC dbo.GetEventsSince2 @d;
GO
/****************************************************************************/
/*                  SQL Friday #94, 4th November 2022                       */
/*                  Author: Milos Radivojevic                               */
/*           Session: Parameter Sniffing in SLQ Server 2022                 */
/****************************************************************************/
/*                 PSP Optimization and Query Store                         */
/*                                                                          */
/****************************************************************************/

USE db2;
GO
----------------------------------------------
-- check the exec statistics in Query Store
----------------------------------------------

DECLARE @sp_name NVARCHAR(200) = N'dbo.GetOrdersTotal';
DECLARE @left DATE = '20221101';
DECLARE @right DATE = '20221104';
WITH c1 AS(
SELECT q.query_hash, q.query_id, p.plan_id, 
rs.runtime_stats_interval_id, execution_type_desc, count_executions, avg_duration
FROM sys.query_store_runtime_stats rs
INNER JOIN sys.query_store_plan p ON p.plan_id=rs.plan_id
INNER JOIN sys.query_store_query q ON p.query_id=q.query_id
WHERE q.object_id=OBJECT_ID(@sp_name) AND CAST(rs.first_execution_time AS DATE) >= @left AND CAST(rs.first_execution_time AS DATE) <= @right
), c2 as(
SELECT runtime_stats_interval_id,query_hash, count_executions, CAST(count_executions*avg_duration AS BIGINT) AS total_dur 
FROM c1
), c3 AS(
SELECT runtime_stats_interval_id,query_hash, MAX(count_executions) maxcount, SUM(total_dur) sum_total_dur
FROM c2
GROUP BY runtime_stats_interval_id,query_hash
)
SELECT (SELECT left(start_time,16) FROM sys.query_store_runtime_stats_interval i Where i.runtime_stats_interval_id=c3.runtime_stats_interval_id) st,
SUM(sum_total_dur)/ (1000*MAX(maxcount)) AS avg_dur
FROM c3
GROUP BY runtime_stats_interval_id
ORDER BY st
GO

--ALTER DATABASE db2 SET QUERY_STORE CLEAR;



 
SELECT * FROM sys.query_store_query;
SELECT * FROM sys.query_store_query_variant;

----------------------------------------------
-- check the exec statistics when PSPO
----------------------------------------------
DECLARE @sp_name NVARCHAR(200) = N'dbo.GetOrdersTotal';
DECLARE @queryvariantds AS TABLE(query_int BIGINT PRIMARY KEY)
INSERT INTO @queryvariantds
SELECT v.query_variant_query_id FROM sys.query_store_query_variant v 
WHERE parent_query_id IN (SELECT query_id FROM sys.query_store_query
WHERE object_id = OBJECT_ID(@sp_name));

;WITH cte as(
SELECT runtime_stats_interval_id,    count_executions,  avg_duration  , count_executions* avg_duration AS total_duration
FROM sys.query_store_runtime_stats rs
INNER JOIN sys.query_store_plan p on p.plan_id = rs.plan_id
INNER JOIN @queryvariantds qv on qv.query_int =  p.query_id
)
SELECT CAST(SUM(total_duration)/(1000.0*SUM(count_executions)) AS INT) 
FROM cte
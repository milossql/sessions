/****************************************************************************/
/*                  SQL Friday #94, 4th November 2022                       */
/*                  Author: Milos Radivojevic                               */
/*           Session: Parameter Sniffing in SLQ Server 2022                 */
/****************************************************************************/
/*                 PSP Optimization Skipped - XE Sessions                   */
/*                                                                          */
/****************************************************************************/
USE master;
GO
CREATE EVENT SESSION psp_skipped_db2 ON SERVER 
ADD EVENT sqlserver.parameter_sensitive_plan_optimization_skipped_reason(
    ACTION(sqlserver.sql_text)
    WHERE ([sqlserver].[database_name] = N'db2' AND [sqlserver].[is_system]=(0))),
ADD EVENT sqlserver.parameter_sensitive_plan_testing(
    ACTION(sqlserver.sql_text))
ADD TARGET package0.event_file(SET filename = N'psp_skipped_db2_file')
WITH (MAX_MEMORY=4096 KB,EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,MAX_DISPATCH_LATENCY=1 SECONDS,MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=NONE,TRACK_CAUSALITY=OFF,STARTUP_STATE=OFF)
GO

USE master;
GO
CREATE EVENT SESSION psp_skipped_ps1 ON SERVER 
ADD EVENT sqlserver.parameter_sensitive_plan_optimization_skipped_reason(
    ACTION(sqlserver.sql_text)
    WHERE ([sqlserver].[database_name] = N'ps1' AND [sqlserver].[is_system]=(0))),
ADD EVENT sqlserver.parameter_sensitive_plan_testing(
    ACTION(sqlserver.sql_text))
ADD TARGET package0.event_file(SET filename = N'psp_skipped_ps1_file')
WITH (MAX_MEMORY=4096 KB,EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,MAX_DISPATCH_LATENCY=1 SECONDS,MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=NONE,TRACK_CAUSALITY=OFF,STARTUP_STATE=OFF)
GO





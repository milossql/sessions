/****************************************************************************/
/*                  SQL Friday #94, 4th November 2022                       */
/*                  Author: Milos Radivojevic                               */
/*           Session: Parameter Sniffing in SLQ Server 2022                 */
/****************************************************************************/
/*                 PSP Optimization and Plan Cache                          */
/*                                                                          */
/****************************************************************************/
----------------------------------------------
-- check the exec plan from cache
----------------------------------------------
USE db2;
GO

--ALTER DATABASE db2 SET COMPATIBILITY_LEVEL = 160;
--GO
--EXEC GetOrdersTotal 1;
--EXEC GetOrdersTotal 4796;
--GO
--sp_recompile 'GetOrdersTotal'
--GO
--EXEC GetOrdersTotal 4796;
--EXEC GetOrdersTotal 1;
--GO

DECLARE @sp_name NVARCHAR(255) = N'GetOrdersTotal';
SELECT 
	ep.usecounts,
	ep.cacheobjtype,
	ep.objtype,
	q.text AS query_text,
	pl.query_plan,
	ep.size_in_bytes
FROM 
	sys.dm_exec_cached_plans ep
	CROSS APPLY sys.dm_exec_sql_text(ep.plan_handle) q
	CROSS APPLY sys.dm_exec_query_plan(ep.plan_handle) pl
WHERE
	ep.objtype = 'Proc' AND q.text LIKE '%' + @sp_name + '%'
GO
----------------------------------------------
-- check the exec statistics
----------------------------------------------
SELECT CONCAT(schema_NAME(schema_id),'.', p.name) AS storedproc,
	d.execution_count,
	ISNULL(d.execution_count*60/(DATEDIFF(second, d.cached_time, GETDATE())), 0) AS calls_per_minute,
	(d.total_elapsed_time/(1000*d.execution_count)) AS [avg_elapsed_time_ms],
	d.total_logical_reads/d.execution_count AS [avg_logical_reads],
	d.last_execution_time,
	d.last_elapsed_time/1000 AS last_elapsed_time_ms,
	d.last_logical_reads,
	d.max_elapsed_time/1000 AS max_elapsed_time_ms,
	d.max_logical_reads
FROM sys.procedures p
INNER JOIN sys.dm_exec_procedure_stats AS d ON p.object_id = d.object_id 
WHERE d.database_id = DB_ID() AND p.name LIKE '%GetOrdersTotal%'
ORDER BY 3 DESC;

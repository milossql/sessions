/****************************************************************************/
/*                  SQL Friday #94, 4th November 2022                       */
/*                  Author: Milos Radivojevic                               */
/*           Session: Parameter Sniffing in SLQ Server 2022                 */
/****************************************************************************/
/*                 PSP Optimization in SQL Server 2022                      */
/*                                                                          */
/****************************************************************************/
USE db2;
SELECT TOP 10 CustomerId, COUNT(*)
FROM Orders
GROUP BY CustomerId
ORDER BY 2 DESC;

SELECT COUNT(*) FROM Orders where CustomerId = 1; --1102154
SELECT COUNT(*) FROM Orders where CustomerId = 2; --901868
SELECT COUNT(*) FROM Orders where CustomerId = 4796; --2
GO

--sample stored procedure
CREATE OR ALTER PROCEDURE dbo.GetOrdersTotal
@CustomerId INT
AS
BEGIN
	SELECT SUM(Amount*1.0) AS SumAmount, COUNT(*) AS CntOrders 
	FROM dbo.Orders 
	WHERE CustomerId = @CustomerId 
END
GO

SELECT SUM(Amount*1.0) AS SumAmount, COUNT(*) AS Cnt FROM dbo.Orders WHERE CustomerId = 1;
SELECT SUM(Amount*1.0) AS SumAmount, COUNT(*) AS Cnt FROM dbo.Orders WHERE  CustomerId = 2;
SELECT SUM(Amount*1.0) AS SumAmount, COUNT(*) AS Cnt FROM dbo.Orders WHERE  CustomerId =  4796;
GO

ALTER DATABASE db2 SET COMPATIBILITY_LEVEL = 150;
GO
EXEC GetOrdersTotal 1;
EXEC GetOrdersTotal 2;
EXEC GetOrdersTotal 4796;
GO
sp_recompile 'GetOrdersTotal'
GO
EXEC GetOrdersTotal 4796;
EXEC GetOrdersTotal 1;
EXEC GetOrdersTotal 2;
GO

ALTER DATABASE db2 SET COMPATIBILITY_LEVEL = 160;
GO
EXEC GetOrdersTotal 1;
EXEC GetOrdersTotal 2;
EXEC GetOrdersTotal 4796;
GO
sp_recompile 'GetOrdersTotal'
GO
EXEC GetOrdersTotal 4796;
EXEC GetOrdersTotal 1;
EXEC GetOrdersTotal 2;
GO


--4th value -8000
SELECT COUNT(*) FROM Orders where CustomerId = 2; --901868
SELECT COUNT(*) FROM Orders where CustomerId = 8000; --965
ALTER DATABASE db2 SET COMPATIBILITY_LEVEL = 150;
GO
EXEC GetOrdersTotal 1;
EXEC GetOrdersTotal 2;
EXEC GetOrdersTotal 8000;
EXEC GetOrdersTotal 4796;
GO
sp_recompile 'GetOrdersTotal'
GO
ALTER DATABASE db2 SET COMPATIBILITY_LEVEL = 160;
GO
EXEC GetOrdersTotal 1;
EXEC GetOrdersTotal 2;
EXEC GetOrdersTotal 8000;
EXEC GetOrdersTotal 4796;
GO



--However
ALTER DATABASE db2 SET COMPATIBILITY_LEVEL = 150;
GO
EXEC GetOrdersTotal 1;
EXEC GetOrdersTotal 8000;
EXEC GetOrdersTotal 2;
EXEC GetOrdersTotal 4796;
GO
sp_recompile 'GetOrdersTotal'
GO
ALTER DATABASE db2 SET COMPATIBILITY_LEVEL = 160;
GO
EXEC GetOrdersTotal 1;
EXEC GetOrdersTotal 8000;
EXEC GetOrdersTotal 2;
EXEC GetOrdersTotal 4796;
GO
/*
 GetOrdersTotal 8000 and  GetOrdersTotal 2 have the same plan with PSP optimization
 however, a good plan for GetOrdersTotal 8000 is Index Seek + key Lookup, and for GetOrdersTotal 2 the beest plan is Scan
 we have here a secondary parameter sniffing, the same plan for Cust with 102 orders and 999.500 orders
 first call decides about the plan, as in classic ps
*/




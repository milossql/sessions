-------------------------------------------------------------------------------------
-- Workshop: Query Store Deep Dive
-- Module 4: Query Store Use Cases - Setup
-- Milos Radivojevic, Data Platform MVP
-- E: milos.radivojevic@chello.at
-- W: https://milossql.wordpress.com/
-------------------------------------------------------------------------------------


USE WideWorldImporters;
GO
CREATE OR ALTER PROCEDURE [dbo].[Which procedures ended with a timeout or an exception today?]
AS
BEGIN
	SELECT OBJECT_NAME(object_id) objname, object_id, execution_type_desc, SUM(count_executions) cnt
	FROM sys.query_store_runtime_stats rs
	INNER JOIN sys.query_store_plan p ON p.plan_id = rs.plan_id
	INNER JOIN sys.query_store_query q ON p.query_id = q.query_id
	WHERE execution_type <> 0 
	AND CAST(first_execution_time AS DATE) = CAST(GETDATE() AS DATE)
	GROUP BY  OBJECT_NAME(object_id), object_id, execution_type_desc;
END
GO

CREATE OR ALTER PROCEDURE  [dbo].[What is the success of the procedure execution today?] (@ProcName NVARCHAR(200))
AS
BEGIN
	SELECT execution_type_desc, SUM(count_executions) cnt 
	FROM sys.query_store_runtime_stats rs
	INNER JOIN sys.query_store_plan p ON p.plan_id = rs.plan_id
	INNER JOIN sys.query_store_query q ON p.query_id = q.query_id
	WHERE object_id = OBJECT_ID(@ProcName)
	AND CAST(first_execution_time AS DATE) = CAST(GETDATE() AS DATE)
	GROUP BY execution_type_desc
	ORDER BY cnt DESC;
END
GO

CREATE OR ALTER PROCEDURE [dbo].[Which queries have more than one plan?] 
AS
BEGIN
	WITH cte AS(
	SELECT query_id, COUNT(*) cnt FROM sys.query_store_plan p 
	GROUP BY query_id
	HAVING COUNT(*) > 1
	)
	SELECT OBJECT_NAME(object_id) objname, q.query_id, qt.query_sql_text, cte.cnt
	FROM sys.query_store_query q 
	INNER JOIN cte ON cte.query_id = q.query_id
	INNER JOIN sys.query_store_query_text qt  ON qt.query_text_id = q.query_text_id
	ORDER BY cnt DESC;
END
GO

CREATE OR ALTER PROCEDURE [dbo].[Show me the list of ad-hoc queries]
AS
BEGIN
	WITH cte AS(SELECT p.query_id 
	FROM sys.query_store_plan p 
	INNER JOIN sys.query_store_runtime_stats s ON p.plan_id = s.plan_id 
	GROUP BY p.query_id 
	HAVING SUM(s.count_executions) = 1
	)
	SELECT q.query_id, qt.query_sql_text
	FROM cte
	INNER JOIN sys.query_store_query q ON q.query_id = cte.query_id
	INNER JOIN sys.query_store_query_text qt ON qt.query_text_id = q.query_text_id;
END
GO

CREATE OR ALTER PROCEDURE [dbo].[What is percentage of ad-hoc queries in the database?]
AS
BEGIN
	WITH c1 AS(
	SELECT p.query_id, CASE WHEN SUM(s.count_executions) = 1 THEN 1 ELSE 0 END is_ad_hoc
	FROM sys.query_store_plan p 
	INNER JOIN sys.query_store_runtime_stats s ON p.plan_id = s.plan_id 
	GROUP BY p.query_id 
	), c2 AS(
	SELECT is_ad_hoc, COUNT(*) cnt
	FROM c1
	GROUP BY is_ad_hoc
	) 
	SELECT CAST((SELECT cnt FROM c2 WHERE is_ad_hoc = 1) *100.0 
	/ 
	(SELECT SUM(cnt) FROM c2) AS DECIMAL(5,2)) perc;
END
GO




-------------------------------------------------------------------------------------
-- Workshop: Query Store Deep Dive
-- Module 4: Query Store Use Cases - Questions
-- Milos Radivojevic, Data Platform MVP
-- E: milos.radivojevic@chello.at
-- W: https://milossql.wordpress.com/
-------------------------------------------------------------------------------------

USE WideWorldImporters;

--Which procedures ended with a timeout or an exception today?
EXEC [dbo].[Which procedures ended with a timeout or an exception today?]
--What is the success of the dbo.GetAllOrders procedure execution today?
EXEC [dbo].[What is the success of the procedure execution today?] 'dbo.GetAllOrders'
--Which queries have more than one plan?
EXEC [dbo].[Which queries have more than one plan?]
--Show me the list of ad-hoc queries
EXEC [dbo].[Show me the list of ad-hoc queries]
--What is percentage of ad-hoc queries in the database?
EXEC [dbo].[What is percentage of ad-hoc queries in the database?]
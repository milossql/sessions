 
USE WideWorldImporters;
DECLARE @sql VARCHAR(500)
DECLARE @i INT = 1
DECLARE @j INT = 1
DECLARE @x INT ,@y INT,@z INT
WHILE @i <=1000
BEGIN
	SET @x = (SELECT 1 + ABS(CHECKSUM(NEWID())) % 27)
	SET @y = (SELECT 1 + ABS(CHECKSUM(NEWID())) % 27)
	IF @x = @y SET @y = @x+1 
	WHILE @j <=10
	BEGIN
		SET @sql = CONCAT('SELECT TOP(',@j,') *
		FROM Sales.Orders o
		INNER JOIN Sales.OrderLines ol ON o.OrderID = ol.OrderID AND 1=0
		ORDER BY ',@x,',', @y)
		EXEC (@sql)
		SET @j = @j +1
	END
	SET @j = 1
SET @i = @i +1
END

 

USE WideWorldImporters;
GO
CREATE OR ALTER PROCEDURE dbo.GetAllOrders
AS
BEGIN
	SELECT *
	FROM Sales.Orders o
	INNER JOIN Sales.OrderLines ol ON o.OrderID = ol.OrderID
	ORDER BY o.ExpectedDeliveryDate;
END
GO

CREATE OR ALTER PROCEDURE dbo.GetTopNOrders (@N INT)
AS
BEGIN
	SELECT TOP(@N) *
	FROM Sales.Orders o
	INNER JOIN Sales.OrderLines ol ON o.OrderID = ol.OrderID
	ORDER BY o.PickedByPersonID;
END
GO

CREATE OR ALTER PROCEDURE dbo.GetTopNOrdersTrivial (@N INT)
AS
BEGIN
	SELECT TOP(@N) *
	FROM Sales.Orders o
	INNER JOIN Sales.OrderLines ol ON o.OrderID = ol.OrderID
	WHERE 1 = 0
	ORDER BY o.CustomerID;
END
GO

CREATE OR ALTER PROCEDURE dbo.GetOrderWithPossibleExceptions
AS
BEGIN
	DECLARE @z INT
	SET @z = (SELECT ABS(CHECKSUM(NEWID())) % 15)
	SELECT o.OrderId*10/@z
	FROM Sales.Orders o
	INNER JOIN Sales.OrderLines ol ON o.OrderID = ol.OrderID
	WHERE o.OrderID = 1
	ORDER BY o.CustomerID;
END
GO


CREATE OR ALTER PROCEDURE dbo.GetOrdersParamSensitive(@Orderdate DATE, @CustomerId INT)
AS
BEGIN
 
	SELECT TOP 10 *
	FROM Sales.Orders o
	WHERE (o.CustomerID = @CustomerId OR @CustomerId IS NULL)
	AND (o.OrderDate = @Orderdate OR @Orderdate IS NULL)
END
GO

CREATE OR ALTER PROCEDURE dbo.GetOrdersForCustomer(@CustomerId INT)
AS
BEGIN
	SELECT *
	FROM Sales.Orders o
	INNER LOOP JOIN Sales.OrderLines ol ON o.OrderID = ol.OrderID
	WHERE o.CustomerID = @CustomerId;
END
GO

CREATE OR ALTER PROCEDURE dbo.GetOrdersForTempValues 
AS
BEGIN
	DECLARE @z INT = (SELECT ABS(CHECKSUM(NEWID())) % 10000)
	DECLARE @y INT = (SELECT ABS(CHECKSUM(NEWID())) % 100)
	DECLARE @x INT = @y
	DECLARE @t TABLE(OrderId INT NOT NULL)
	IF (@z > 50000) SET @x = @z 
	SELECT n OrderId INTO #t FROM dbo.GetNums(@x);
 
	SELECT *
	FROM #t  t
	INNER JOIN Sales.Orders o ON o.OrderID = t.OrderID
	INNER JOIN Sales.OrderLines ol ON o.OrderID = ol.OrderID
	WHERE o.OrderID = 1
	ORDER BY o.CustomerID;
END
GO


USE WideWorldImporters;
--workload
DECLARE @j INT = 1
WHILE @j < 10
BEGIN
 
	EXEC dbo.GetOrdersForTempValues;
	EXEC dbo.GetOrdersParamSensitive '20130101', NULL;
	EXEC dbo.GetOrdersParamSensitive NULL, 803;
	EXEC dbo.GetOrdersForTempValues;
	EXEC dbo.GetOrdersParamSensitive '20230101', NULL;
	EXEC dbo.GetOrdersParamSensitive NULL, 81103;
	ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE;
	EXEC dbo.GetOrdersParamSensitive '20230101', NULL;
	EXEC dbo.GetOrdersParamSensitive NULL, 81103;
	ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE;
	EXEC dbo.GetOrdersParamSensitive NULL, 81103;
	EXEC dbo.GetOrdersParamSensitive '20230101', NULL;
	EXEC dbo.GetOrdersParamSensitive NULL, 81103;
	EXEC dbo.GetOrdersForTempValues;
	DECLARE @i INT = 1
	WHILE @i < 100
	BEGIN
		EXEC dbo.GetOrderWithPossibleExceptions
		EXEC dbo.GetTopNOrdersTrivial @i
		EXEC dbo.GetOrdersParamSensitive NULL, 803;
		EXEC dbo.GetOrdersParamSensitive '20230101', NULL;
		if @i % 5 = 0
			EXEC dbo.GetTopNOrders @i
		if @i % 10 = 0
			EXEC dbo.GetAllOrders
		ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE;
		EXEC dbo.GetOrdersParamSensitive '20130101', NULL;
		EXEC dbo.GetOrdersParamSensitive NULL, 81103;
		SET @i = @i +1
	END
	SET @j = @j +1
END
GO
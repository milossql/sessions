 
USE WideWorldImporters;
--workload
ALTER INDEX FK_Sales_Orders_CustomerID ON Sales.Orders REBUILD;
EXEC dbo.GetOrdersForCustomer 9991;
EXEC dbo.GetOrdersForCustomer 111;
ALTER INDEX FK_Sales_Orders_CustomerID ON Sales.Orders DISABLE;
DECLARE @j INT = 1
DECLARE @name VARCHAR(500) = 'ix'
WHILE @j < 10
BEGIN

	EXEC dbo.GetOrdersForCustomer 9991;
	EXEC dbo.GetOrdersForCustomer 111;
	SET @name = CONCAT('CREATE INDEX ix',@j, ' ON Sales.Orders(CustomerID);')
	EXEC (@name)
	EXEC dbo.GetOrdersForCustomer 9991;
	EXEC dbo.GetOrdersForCustomer 111;
	SET @name = CONCAT('DROP INDEX ix',@j, ' ON Sales.Orders')
	EXEC (@name) 
	SET @j = @j +1
END
GO


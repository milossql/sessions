USE WideWorldImporters;
GO
--clear and turn on Query Store
ALTER DATABASE WideWorldImporters SET QUERY_STORE CLEAR ALL;
GO
ALTER DATABASE WideWorldImporters SET QUERY_STORE = ON(
	OPERATION_MODE = READ_WRITE, 
	MAX_STORAGE_SIZE_MB = 1000,
	SIZE_BASED_CLEANUP_MODE = AUTO,
	QUERY_CAPTURE_MODE = AUTO,
	INTERVAL_LENGTH_MINUTES = 60
);
GO
SELECT ol.OrderID, ol.UnitPrice, ol.StockItemID 
FROM Sales.Orderlines ol
INNER JOIN dbo.SignificantOrders() f1 ON f1.Id = ol.OrderID
WHERE PackageTypeID = 7
GO 12
--Set the compatibility mode to SQL Server 2016 and run the query with Include Actual Execution Plan
GO
EXEC dbo.GetOrderDetails 112;
GO 34
ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE;
GO
EXEC dbo.GetOrderDetails 36;
GO 32

SELECT ColdRoomSensorNumber, COUNT(*) FROM  Warehouse.ColdRoomTemperatures_Archive
GROUP BY ColdRoomSensorNumber;
GO 33
GO
;WITH cte AS(
SELECT ColdRoomTemperatureID, ROW_NUMBER() OVER(PARTITION BY ColdRoomTemperatureID ORDER BY ColdRoomTemperatureID) rn 
FROM WarehoUSE.ColdRoomTemperatures_Archive
)
SELECT * FROM cte WHERE rn > 1
GO 20
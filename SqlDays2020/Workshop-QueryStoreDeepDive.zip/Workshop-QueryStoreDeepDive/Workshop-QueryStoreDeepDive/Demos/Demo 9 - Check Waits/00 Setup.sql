USE WideWorldImporters;
GO
CREATE OR ALTER PROCEDURE dbo.GetOrderDetails
@UnitPrice DECIMAL(18,2)
AS
SELECT o.OrderID, o.OrderDate, ol.OrderLineID, ol.Quantity, ol.UnitPrice
FROM Sales.OrderLines ol
INNER JOIN Sales.Orders o ON ol.OrderID = o.OrderID
WHERE ol.UnitPrice = @UnitPrice;
GO

CREATE OR ALTER FUNCTION dbo.SignificantOrders()
RETURNS @T TABLE
(ID    INT  NOT NULL)
AS
BEGIN
    INSERT INTO @T
	SELECT OrderId FROM Sales.Orders
    RETURN
END
GO
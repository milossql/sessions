-------------------------------------------------------------------------------------
-- Workshop: Query Store Deep Dive
-- Module 5: Plan Forcing
-- Plan Forcing Failure
-- Milos Radivojevic, Data Platform MVP
-- E: milos.radivojevic@chello.at
-- W: https://milossql.wordpress.com/
-------------------------------------------------------------------------------------


USE WideWorldImporters;
GO
CREATE OR ALTER PROCEDURE dbo.GetSalesOrdersSince 
	@OrderDate DATETIME
AS
	SELECT *
	FROM Sales.Orders o
	INNER JOIN Sales.OrderLines ol ON o.OrderID = ol.OrderID
	WHERE OrderDate >= @OrderDate
	ORDER BY o.ExpectedDeliveryDate DESC;
GO
 
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE name = 'i1' AND object_id = OBJECT_ID('Sales.Orders'))
	CREATE INDEX i1 ON Sales.Orders(OrderDate);
GO


--clear and turn on Query Store
ALTER DATABASE WideWorldImporters SET QUERY_STORE CLEAR;
GO
ALTER DATABASE WideWorldImporters SET QUERY_STORE = ON;
GO

--call the SP
EXEC dbo.GetSalesOrdersSince '20170101';
--force the plan
EXEC sp_query_store_force_plan @query_id = 1, @plan_id = 1;
GO
--remove the index
DROP INDEX i1 ON Sales.Orders;
GO
--call the SP again
EXEC dbo.GetSalesOrdersSince '20150101';
GO
--SQL Server tried to create a plan with forced plan as a shape and failed
-- but it creates a new plan
ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE;
GO
EXEC dbo.GetSalesOrdersSince '20150101';
GO
--the faulure count is incremented

--when you create an index on the given column, but with different name, forcing won't work
CREATE INDEX i2 ON Sales.Orders(OrderDate);
GO
EXEC dbo.GetSalesOrdersSince '20150101';
GO

--when you create the index with that name but different column, forcing won't work
CREATE INDEX i1 ON Sales.Orders(CustomerId);
GO
EXEC dbo.GetSalesOrdersSince '20150101';
GO
--this time forcing failure reason is NO_PLAN
GO
DROP INDEX i2 ON Sales.Orders;DROP INDEX i1 ON Sales.Orders;
GO

--Index name and leading column must be the same
CREATE INDEX i1 ON Sales.Orders(OrderDate, CustomerId);
GO
EXEC dbo.GetSalesOrdersSince '20150101';
--this time forcing plan works
GO

--In case of index hnts, you'll always get an exception

CREATE INDEX i1 ON Sales.Orders(OrderDate) WITH DROP_EXISTING;
GO
---------------------------------------
----- simple query with index hint
------------------------------------------

SELECT * FROM Sales.Orders WITH (INDEX(i1)) WHERE OrderDate >= '20190505';

DROP INDEX i1 ON Sales.Orders;

SELECT * FROM Sales.Orders WITH (INDEX(i1)) WHERE OrderDate >= '20190505';
GO

 
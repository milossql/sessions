--Check query_ids
SELECT * FROM sys.query_store_query_text;
SELECT * FROM sys.query_store_query;
SELECT * FROM sys.query_context_settings;
 --ARITHABORT:4096
select cast(0x000010FB as int) - cast(0x000000FB as int)
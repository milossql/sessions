IF DB_ID('QueryCaptureMode') IS NULL CREATE DATABASE QueryCaptureMode;
GO
USE QueryCaptureMode;
GO
DROP TABLE IF EXISTS dbo.T;
CREATE TABLE dbo.T(id INT, c1 INT, c2 INT);
GO
INSERT INTO T VALUES(1,1,1);
GO
ALTER DATABASE QueryCaptureMode SET QUERY_STORE CLEAR;
GO
ALTER DATABASE QueryCaptureMode SET QUERY_STORE = ON;
GO
GO
CREATE OR ALTER PROCEDURE dbo.P
AS
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE name = 'ix' AND object_id = OBJECT_ID('dbo.T'))
	CREATE INDEX ix ON dbo.T(id);
GO
IF NOT EXISTS(SELECT 1 FROM sys.indexes WHERE name = 'ix2' AND object_id = OBJECT_ID('dbo.T'))
	CREATE INDEX ix2 ON dbo.T(id);
GO
EXEC dbo.P;
GO
USE WideWorldImporters;
ALTER DATABASE WideWorldImporters SET QUERY_STORE CLEAR;
GO
ALTER DATABASE WideWorldImporters SET QUERY_STORE = ON;
GO
--SELECT OrderDate, ol.PackageTypeID,  COUNT(*), SUM(Quantity*UnitPrice)
--FROM Sales.Orders o
--INNER JOIN Sales.OrderLines ol ON o.OrderID = ol.OrderID
--GROUP BY  OrderDate,ol.PackageTypeID
--GO 2


SELECT TOP 20000 * FROM Sales.OrderLines 
WHERE   PackageTypeID = 7;
GO 5
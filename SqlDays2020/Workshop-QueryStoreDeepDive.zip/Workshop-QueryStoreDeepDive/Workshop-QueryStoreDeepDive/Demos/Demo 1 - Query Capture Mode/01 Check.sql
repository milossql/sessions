USE QueryCaptureMode;
GO
SELECT * FROM sys.query_store_query_text;
SELECT * FROM sys.query_store_query;
SELECT * FROM sys.query_store_plan;
SELECT * FROM sys.query_store_runtime_stats;
SELECT * FROM sys.query_store_runtime_stats_interval;
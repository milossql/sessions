-------------------------------------------------------------------------------------
-- Workshop: Query Store Deep Dive
-- Module 7: Query Store - Capturing Waits
-- Ignoring Forced Plans - using table-valued parameters
-- Milos Radivojevic, Data Platform MVP
-- E: milos.radivojevic@chello.at
-- W: https://milossql.wordpress.com/
-------------------------------------------------------------------------------------
--restore the QSWaits backup
use  QSWaits
GO

--Create a sample table
DROP TABLE IF EXISTS dbo.T1;
CREATE TABLE dbo.T1(
id INT IDENTITY(1,1) NOT NULL,
c1 INT NOT NULL,
c2 INT NOT NULL,
c3 CHAR(50) NOT NULL DEFAULT 'test',
CONSTRAINT PK_T1 PRIMARY KEY CLUSTERED (id ASC)
);
GO

CREATE PROCEDURE dbo.InsertT1 (@c1 INT)
AS
BEGIN
	INSERT INTO T1(c1,c2) VALUES(@c1, @c1);
END
GO
select count(*) from t1

select * from sys.query_store_runtime_stats where plan_id=1
select * from sys.query_store_wait_stats


begin tran
alter table t1 add c4 int
rollback

select runtime_stats_interval_id, CAST(avg_duration as INT) avgdur 
from sys.query_store_runtime_stats where plan_id=1 AND execution_type = 0
order by 1

select i.start_time,CAST(avg_duration as INT) avgdur 
from sys.query_store_runtime_stats rs
inner join sys.query_store_runtime_stats_interval i On i.runtime_stats_interval_id = rs.runtime_stats_interval_id
where plan_id=1 AND execution_type = 0 order by i.start_time 

select *
from sys.query_store_wait_stats where plan_id=1 AND runtime_stats_interval_id IN ( 11)
select *
from sys.query_store_wait_stats where plan_id=1 AND runtime_stats_interval_id IN (22, 23)

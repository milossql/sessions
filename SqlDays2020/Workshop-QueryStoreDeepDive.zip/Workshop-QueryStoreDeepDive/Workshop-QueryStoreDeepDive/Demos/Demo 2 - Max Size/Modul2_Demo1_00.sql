-------------------------------------------------------------------------------------
-- Workshop: Query Store 
-- Module 2: Configuration - MaxSize
-- Milos Radivojevic, Data Platform MVP
-- E: milos.radivojevic@chello.at
-- W: https://milossql.wordpress.com/
-------------------------------------------------------------------------------------

USE WideWorldImporters;
GO
--Demo 1 Modul 2
DECLARE @sql VARCHAR(500)
DECLARE @i INT = 1
DECLARE @j INT = 1
DECLARE @x INT ,@y INT,@z INT
WHILE @i <=2000
BEGIN
	SET @x = (SELECT 1 + ABS(CHECKSUM(NEWID())) % 27)
	SET @y = (SELECT 1 + ABS(CHECKSUM(NEWID())) % 27)
	IF @x = @y SET @y = @x+1 
	WHILE @j <=10
	BEGIN
		SET @sql = CONCAT('SELECT TOP(',@j,') *
		FROM Sales.Orders o
		INNER JOIN Sales.OrderLines ol ON o.OrderID = ol.OrderID AND 1=0
		ORDER BY ',@x,',', @y)
		EXEC (@sql)
		SET @z = (SELECT ABS(CHECKSUM(NEWID())) % 100)
		SET @sql = CONCAT('SELECT *,', @z, ' AS al  
		FROM Sales.Orders o
		INNER JOIN Sales.OrderLines ol ON o.OrderID = ol.OrderID AND 1=0
		ORDER BY ',@x,',', @y)
		EXEC (@sql)
		SET @j = @j +1
	END
	SET @j = 1
SET @i = @i +1
END
GO

 
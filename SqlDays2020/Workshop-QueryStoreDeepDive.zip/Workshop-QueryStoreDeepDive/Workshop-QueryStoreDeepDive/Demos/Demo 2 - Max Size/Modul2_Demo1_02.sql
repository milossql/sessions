-------------------------------------------------------------------------------------
-- Workshop: Query Store 
-- Module 2: Configuration - MaxSize
-- Milos Radivojevic, Data Platform MVP
-- E: milos.radivojevic@chello.at
-- W: https://milossql.wordpress.com/
-------------------------------------------------------------------------------------

USE WideWorldImporters;
GO
DROP TABLE IF EXISTS #SpaceUsed
CREATE TABLE #SpaceUsed (
	 TableName sysname
	,NumRows BIGINT
	,ReservedSpace VARCHAR(50)
	,DataSpace VARCHAR(50)
	,IndexSize VARCHAR(50)
	,UnusedSpace VARCHAR(50)
	) 

DECLARE @str VARCHAR(500)
SET @str =  'sp_spaceused ''[sys].[plan_persist_query_text]'''
INSERT INTO #SpaceUsed exec(@str)
SET @str =  'sp_spaceused ''[sys].[plan_persist_query]'''
INSERT INTO #SpaceUsed exec(@str)
SET @str =  'sp_spaceused ''[sys].[plan_persist_plan]'''
INSERT INTO #SpaceUsed exec(@str)
SET @str =  'sp_spaceused ''[sys].[plan_persist_runtime_stats]'''
INSERT INTO #SpaceUsed exec(@str)
SET @str =  'sp_spaceused ''[sys].[plan_persist_wait_stats]'''
INSERT INTO #SpaceUsed exec(@str)
SET @str =  'sp_spaceused ''[sys].[plan_persist_runtime_stats_interval]'''
INSERT INTO #SpaceUsed exec(@str)

SELECT *  
FROM #SpaceUsed
 
SELECT  CAST(
SUM(CAST(TRIM(REPLACE(ReservedSpace,'KB','')) AS INT)) /1.024 
AS INT) space_in_kb
FROM #SpaceUsed
-------------------------------------------------------------------------------------
-- Workshop: Query Store 
-- Module 2: Configuration - MaxSize
-- Milos Radivojevic, Data Platform MVP
-- E: milos.radivojevic@chello.at
-- W: https://milossql.wordpress.com/
-------------------------------------------------------------------------------------

USE WideWorldImporters;
GO
--clear and turn on Query Store
ALTER DATABASE WideWorldImporters SET QUERY_STORE CLEAR ALL;
GO
ALTER DATABASE WideWorldImporters SET QUERY_STORE = ON(
	OPERATION_MODE = READ_WRITE, 
	MAX_STORAGE_SIZE_MB = 100, 
	SIZE_BASED_CLEANUP_MODE = OFF,
	QUERY_CAPTURE_MODE = ALL,
	INTERVAL_LENGTH_MINUTES = 1
);
GO

SELECT desired_state_desc, actual_state_desc, readonly_reason, 
current_storage_size_mb, max_storage_size_mb, size_based_cleanup_mode
FROM sys.database_query_store_options;


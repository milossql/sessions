-------------------------------------------------------------------------------------
-- Workshop: Query Store Deep Dive
-- Module 6: Automatic Tuning - Online 
-- Milos Radivojevic, Data Platform MVP
-- E: milos.radivojevic@chello.at
-- W: https://milossql.wordpress.com/
-------------------------------------------------------------------------------------

USE NewDB;
GO
ALTER DATABASE NewDB SET QUERY_STORE CLEAR;
GO
ALTER DATABASE NewDB SET QUERY_STORE = ON (
QUERY_CAPTURE_MODE = CUSTOM,
QUERY_CAPTURE_POLICY =
(
EXECUTION_COUNT = 10,
TOTAL_COMPILE_CPU_TIME_MS = 100,
TOTAL_EXECUTION_CPU_TIME_MS = 100,
STALE_CAPTURE_POLICY_THRESHOLD = 1 day
)
)
GO
ALTER DATABASE NewDB SET COMPATIBILITY_LEVEL = 140;
GO
ALTER DATABASE current SET AUTOMATIC_TUNING (FORCE_LAST_GOOD_PLAN = ON); 
GO

--Ensure that the Discard results after execution option is turned on
--run query with CL 110
EXEC dbo.GetEventsSince '20200101'
GO 40

 
ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE;
GO
--run the same query
EXEC dbo.GetEventsSince '20150101'
GO 50
-------------------------------------------------------------------------------------
-- Workshop: Query Store Deep Dive
-- Module 3: Query Store in Action - Upgrade
-- Milos Radivojevic, Data Platform MVP
-- E: milos.radivojevic@chello.at
-- W: https://milossql.wordpress.com/
-------------------------------------------------------------------------------------

USE WideWorldImporters;
GO
ALTER DATABASE WideWorldImporters SET QUERY_STORE CLEAR;
GO
ALTER DATABASE WideWorldImporters SET QUERY_STORE = OFF;
GO
ALTER DATABASE WideWorldImporters SET QUERY_STORE = ON;
GO
ALTER DATABASE WideWorldImporters SET COMPATIBILITY_LEVEL = 110;
GO
--Ensure that the Discard results after execution option is turned on
--run query with CL 110
SELECT * FROM Sales.Orders o
INNER JOIN Sales.OrderLines ol ON o.OrderID = ol.OrderID
WHERE o.PickedByPersonID IN (0, 900);
GO 50

--change CL to the latest one
ALTER DATABASE WideWorldImporters SET COMPATIBILITY_LEVEL = 150;
GO

--run the same query
SELECT * FROM Sales.Orders o
INNER JOIN Sales.OrderLines ol ON o.OrderID = ol.OrderID
WHERE o.PickedByPersonID IN (0, 900);
GO 50
 
 --ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE;

EXEC sp_query_store_force_plan  @query_id = 1 , @plan_id = 1
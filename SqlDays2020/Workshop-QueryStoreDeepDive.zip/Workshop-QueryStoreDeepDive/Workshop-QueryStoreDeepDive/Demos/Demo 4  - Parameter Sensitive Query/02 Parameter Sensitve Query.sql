-------------------------------------------------------------------------------------
-- Workshop: Query Store Deep Dive
-- Module 3: Query Store in Action - Parameter Sensitive Query
-- Milos Radivojevic, Data Platform MVP
-- E: milos.radivojevic@chello.at
-- W: https://milossql.wordpress.com/
-------------------------------------------------------------------------------------

 
USE NewDB;
GO
--create a sample table:
--help function GetNums originaly created by Itzik Ben-Gan (http://tsql.solidq.com)
IF OBJECT_ID('dbo.GetNums') IS NOT NULL DROP FUNCTION dbo.GetNums;
GO
CREATE FUNCTION dbo.GetNums(@n AS BIGINT) RETURNS TABLE
AS
RETURN
  WITH
  L0   AS(SELECT 1 AS c UNION ALL SELECT 1),
  L1   AS(SELECT 1 AS c FROM L0 AS A CROSS JOIN L0 AS B),
  L2   AS(SELECT 1 AS c FROM L1 AS A CROSS JOIN L1 AS B),
  L3   AS(SELECT 1 AS c FROM L2 AS A CROSS JOIN L2 AS B),
  L4   AS(SELECT 1 AS c FROM L3 AS A CROSS JOIN L3 AS B),
  L5   AS(SELECT 1 AS c FROM L4 AS A CROSS JOIN L4 AS B),
  Nums AS(SELECT ROW_NUMBER() OVER(ORDER BY (SELECT NULL)) AS n FROM L5)
  SELECT n FROM Nums WHERE n <= @n;
GO

--Create a sample table
DROP TABLE IF EXISTS dbo.Events;
CREATE TABLE dbo.Events(
Id INT IDENTITY(1,1) NOT NULL,
EventType TINYINT NOT NULL,
EventDate DATETIME NOT NULL,
Note CHAR(100) NOT NULL DEFAULT 'test',
CONSTRAINT PK_Events PRIMARY KEY CLUSTERED (id ASC)
);
GO
-- Populate the table with 10M rows
DECLARE @date_from DATETIME = '20000101';
DECLARE @date_to DATETIME = '20190901';
DECLARE @number_of_rows INT = 1000000;
INSERT INTO dbo.Events(EventType,EventDate)
SELECT 1 + ABS(CHECKSUM(NEWID())) % 5 AS eventtype,
(SELECT(@date_from +(ABS(CAST(CAST( NewID() AS BINARY(8)) AS INT))%CAST((@date_to - @date_from)AS INT)))) AS EventDate
FROM dbo.GetNums(@number_of_rows)
GO
--Create index on the orderdate column
CREATE INDEX ix1 ON dbo.Events(EventDate);
GO
CREATE OR ALTER PROCEDURE dbo.GetEventsSince
@OrderDate DATETIME
AS
BEGIN
	SELECT * FROM dbo.Events
	WHERE EventDate >= @OrderDate
	ORDER BY Note DESC;
END
GO


ALTER DATABASE NewDB SET COMPATIBILITY_LEVEL = 140;
GO
--setup Query Store
ALTER DATABASE NewDB SET QUERY_STORE CLEAR;
GO

ALTER DATABASE NewDB SET QUERY_STORE = ON;
GO

EXEC dbo.GetEventsSince '20200101' -- 0 rows
GO 5000
ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE;
EXEC dbo.GetEventsSince '20150101' --237K rows
GO 5

---force plan
--call again
EXEC dbo.GetEventsSince '20150101' --237K rows
GO 5

-------------------------------------------
-- A trap: First call high selective
-------------------------------------------

ALTER DATABASE NewDB SET COMPATIBILITY_LEVEL = 140;
GO
--setup Query Store
ALTER DATABASE NewDB SET QUERY_STORE CLEAR;
GO

ALTER DATABASE NewDB SET QUERY_STORE = ON;
GO

EXEC dbo.GetEventsSince '20200101' -- 0 rows
GO 50 
ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE;
EXEC dbo.GetEventsSince '20150101' --237K rows
GO 5

---force plan
--- call with high selective
EXEC dbo.GetEventsSince '20190825'
GO 5
EXEC dbo.GetEventsSince '20150101' --237K rows
GO 10


 
 
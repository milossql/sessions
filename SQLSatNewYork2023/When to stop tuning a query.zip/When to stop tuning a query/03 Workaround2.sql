/****************************************************************************/
/*                  SQL Saturday New York City, May 6 2023                  */
/*                        Author: Milos Radivojevic                         */
/*                       When to Stop Tuning a Query?                       */
/****************************************************************************/
/*  Tuning a query with large tables - using cardinality estimation tricks  */
/*                                                                          */
/****************************************************************************/

USE xSQLPASS2022;
GO
--initial query
SELECT * FROM dbo.Orders o
INNER JOIN dbo.OrderDetails od ON o.OrderId = od.OrderId
WHERE o.CustomerId = 987004
ORDER BY od.Cols;

--workaround 2
DECLARE @Orders TABLE(
	OrderID INT NOT NULL PRIMARY KEY,
	CustomerID INT NOT NULL,
	Cols CHAR(100) NOT NULL
	)

INSERT INTO @Orders(OrderID, CustomerID, Cols)
SELECT OrderID, CustomerID, Cols
FROM dbo.Orders o
WHERE o.CustomerId = 987004

SELECT * FROM @Orders o
INNER JOIN dbo.OrderDetails od ON o.OrderId=od.OrderId
ORDER BY od.Cols

/*
check the execution plan
*/

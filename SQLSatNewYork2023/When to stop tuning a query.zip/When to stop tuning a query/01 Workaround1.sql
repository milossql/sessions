/****************************************************************************/
/*                  SQL Saturday New York City, May 6 2023                  */
/*                        Author: Milos Radivojevic                         */
/*                       When to Stop Tuning a Query?                       */
/****************************************************************************/
/*               Tuning a query with large tables - using hints             */
/*                                                                          */
/****************************************************************************/

USE xSQLPASS2022;

--workaround 1 - the LOOP hint
SELECT * FROM dbo.Orders o
INNER LOOP JOIN dbo.OrderDetails od ON o.OrderId = od.OrderId
WHERE o.CustomerId = 987004
ORDER BY od.Cols;
/*
10 GB memory grant!!!
*/
--when it's invoked in 200 parallel sessions
--SQLQueryStress Tool 

--2. hint - MAX_GRANT_PERCENT
SELECT * FROM dbo.Orders o
INNER LOOP JOIN dbo.OrderDetails od ON o.OrderId = od.OrderId
WHERE o.CustomerId = 987004
ORDER BY od.Cols
OPTION (MAX_GRANT_PERCENT = 0.05);
/*
8.8 MB memory grant
*/
--3. hint - MAXDOP 1
SELECT * FROM dbo.Orders o
INNER LOOP JOIN dbo.OrderDetails od ON o.OrderId = od.OrderId
WHERE o.CustomerId = 987004
ORDER BY od.Cols
OPTION (MAX_GRANT_PERCENT = 0.05, MAXDOP 1);



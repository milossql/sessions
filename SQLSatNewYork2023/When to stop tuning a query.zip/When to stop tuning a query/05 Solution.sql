/****************************************************************************/
/*                  SQL Saturday New York City, May 6 2023                  */
/*                        Author: Milos Radivojevic                         */
/*                       When to Stop Tuning a Query?                       */
/****************************************************************************/
/*           Tuning a query with large tables - updating statistics         */
/*                                                                          */
/****************************************************************************/

USE xSQLPASS2022;
GO
--a proper solution
UPDATE STATISTICS Orders ix1 WITH SAMPLE 70 PERCENT;
UPDATE STATISTICS OrderDetails ix1 WITH SAMPLE 20 PERCENT;
GO

--original query
SELECT * FROM dbo.Orders o
INNER JOIN dbo.OrderDetails od ON o.OrderId = od.OrderId
WHERE o.CustomerId = 987004
ORDER BY od.Cols;


--UPDATE STATISTICS Orders ix1 WITH SAMPLE 70 PERCENT 
--UPDATE STATISTICS OrderDetails ix1 WITH SAMPLE 30 PERCENT 

 
dbcc show_statistics ('Orders','ix1')
select * from sys.dm_db_stats_histogram(object_id('Orders'),2) order by equal_rows desc

 
select SQRT(1000.0*100000000)
select SQRT(1000.0*336000000)

begin tran
	;with cte as(
	select top 317 * from Orders)
	update cte set CustomerId = 9
	go 1000
rollback

begin tran
	;with cte as(
	select top 580 * from OrderDetails)
	update cte set orderid = 696
	go 1000
rollback

 

--UPDATE STATISTICS Orders ix1 WITH SAMPLE 70 PERCENT, PERSIST_SAMPLE_PERCENT = ON 
--UPDATE STATISTICS OrderDetails ix1 WITH SAMPLE 30 PERCENT, PERSIST_SAMPLE_PERCENT = ON 



/****************************************************************************/
/*                  SQL Saturday New York City, May 6 2023                  */
/*                        Author: Milos Radivojevic                         */
/*                       When to Stop Tuning a Query?                       */
/****************************************************************************/
/*  Tuning a query with large tables - using mem-optimized table variables  */
/*                                                                          */
/****************************************************************************/

USE xSQLPASS2022;
GO
 
--workaround 2
DECLARE @Orders AS dbo.OrderType

INSERT INTO @Orders(OrderID, CustomerID, Cols)
SELECT OrderID, CustomerID, Cols
FROM dbo.Orders o
WHERE o.CustomerId = 987004

SELECT * FROM @Orders o
INNER JOIN dbo.OrderDetails od ON o.OrderId=od.OrderId
ORDER BY od.Cols

/*
check the execution plan
*/

-------------------------------------------------------------------------------------
-- Session: Transact-SQL Tips - Data Conversions
-- Milos Radivojevic, Data Platform MVP, bwin, Austria
-- E: milos.radivojevic@chello.at
-- W: https://milossql.wordpress.com/
-------------------------------------------------------------------------------------
---------------------------------------------------------------------
-- Settings
---------------------------------------------------------------------
SET STATISTICS IO ON; --include IO statistics
SET NOCOUNT ON; --do not show affected rows info
--INCLUDE ACTUAL EXECUTION PLAN
GO
USE AdventureWorks2019;

-- Create and populate tables dbo.Contacts
DROP TABLE IF EXISTS dbo.Contacts;
GO
SELECT * INTO dbo.Contacts FROM AdventureWorks2019.Person.Person;
--Create clustered index on ContactID and nonclustered on the LastName
CREATE UNIQUE CLUSTERED INDEX PK_Contacts ON dbo.Contacts(BusinessEntityID);
GO
CREATE INDEX ix1 ON dbo.Contacts(LastName);
GO

---------------------------------------------------------------------
--Data Type Conversions
---------------------------------------------------------------------

-- 3.1 nvarchar column and varchar argument - NOTHING happens
SELECT FirstName, LastName FROM dbo.Contacts WHERE LastName ='Atkinson';
GO
SELECT FirstName, LastName FROM dbo.Contacts WHERE LastName = N'Atkinson';
--Result: 50% : 50% 

--Add new column with VARCHAR type, update and index it
ALTER TABLE dbo.Contacts ADD LastName2 VARCHAR(50);
GO
UPDATE dbo.Contacts SET LastName2 = LastName;
GO
CREATE INDEX ix2 ON dbo.Contacts(LastName2);
GO

--VARCHAR column and NVARCHAR argument - CONVERSION needed
SELECT FirstName,LastName2 FROM dbo.Contacts WHERE LastName2 = 'Atkinson';
SELECT FirstName,LastName2 FROM dbo.Contacts WHERE LastName2 = N'Atkinson';


--Result: 5% : 95% (Conversion overhead is significant; non-unicode will be converted to Unicode)
--Logical Reads: 5 vs. 54

--Equivalent to an explicit conversion
SELECT FirstName, LastName2 FROM dbo.Contacts WHERE LastName2 = N'Atkinson';
SELECT FirstName, LastName2 FROM dbo.Contacts WHERE CONVERT(NVARCHAR(50),LastName2)= N'Atkinson';


--Solution: Use the column data type for argument too, or explicitely convert the argument data type to the column data type
SELECT FirstName, LastName2 FROM dbo.Contacts WHERE LastName2 ='Atkinson';
SELECT FirstName, LastName2 FROM dbo.Contacts WHERE LastName2 = CONVERT(VARCHAR(50),N'Atkinson')

--Clean up
DROP INDEX ix2 ON dbo.Contacts;
ALTER TABLE dbo.Contacts DROP COLUMN LastName2;
GO

--conversion penalties
USE TSQLTips;
GO
SELECT * FROM dbo.Orders WHERE CustId =  989;
SELECT * FROM dbo.Orders WHERE CustId =  '989';

 
 --------------------------------------------
--Predicate evaluation order
--------------------------------------------
--TASK: Get all records from the Address table for the city Tacoma and ZIP 98403
--PostalCode is alphanumeric
--This works
USE AdventureWorks2019;
SELECT * FROM Person.Address 
WHERE City = 'Tacoma' AND PostalCode = 98403;
--(96 row(s) affected)

--This one doesn't work
SELECT * FROM Person.Address 
WHERE City LIKE 'Tacoma' AND  PostalCode =98403;
--Conversion failed when converting the nvarchar value 'K4B 1S2' to data type int.
--There is no guarantee that operation against the City column will be evaluated first!

 --This one works regardless the evaluation order
SELECT * FROM Person.Address 
WHERE City LIKE 'Tacoma' AND  CASE WHEN PostalCode NOT LIKE '%[^0-9]%' THEN PostalCode END = 98403;
--(96 row(s) affected)

--This one works regardless the evaluation order (let's remove the City column)
SELECT * FROM Person.Address 
WHERE  CASE WHEN PostalCode NOT LIKE '%[^0-9]%' THEN PostalCode END = 98403;
--(96 row(s) affected)
SELECT * FROM Person.Address 
WHERE City LIKE 'Tacoma' AND PostalCode = N'98403';

SELECT * FROM Person.Address 
WHERE ISNUMERIC(PostalCode) = 1 AND  PostalCode = 98403;
--(90 row(s) affected)

SELECT ISNUMERIC(',')
SELECT ISNUMERIC('/')
SELECT ISNUMERIC('#')
SELECT ISNUMERIC('+')
SELECT ISNUMERIC('$')
SELECT ISNUMERIC('	')
 SELECT ISNUMERIC('0d2345')
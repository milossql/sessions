-------------------------------------------------------------------------------------
-- Session: Transact-SQL Tips - Local Variables
-- Milos Radivojevic, Data Platform MVP, bwin, Austria
-- E: milos.radivojevic@chello.at
-- W: https://milossql.wordpress.com/
-------------------------------------------------------------------------------------
USE TSQLTips;
SET NOCOUNT ON;
SET STATISTICS TIME ON;
GO
IF OBJECT_ID('dbo.Orders', 'U') IS NOT NULL DROP TABLE dbo.Orders;
CREATE TABLE dbo.Orders(
Id INT NOT NULL,
CustomerId INT NOT NULL,
OrderDate DATETIME NOT NULL,
Amount INT NOT NULL,
Other CHAR(500) NOT NULL DEFAULT 'test',
CONSTRAINT PK_Orders PRIMARY KEY CLUSTERED (Id ASC)
);
GO
CREATE INDEX ix1 ON dbo.Orders(OrderDate)
GO
CREATE INDEX ix2 ON dbo.Orders(CustomerId)
GO

DECLARE @date_from DATETIME = '19850101';
DECLARE @date_to DATETIME = '20200920';
INSERT INTO dbo.Orders(id,CustomerId,OrderDate,Amount)
SELECT n AS id, 
 1 + ABS(CHECKSUM(NEWID())) % 1000000 AS CustomerId,

 (SELECT(@date_from +(ABS(CAST(CAST( NewID() AS BINARY(8) )AS INT))%CAST((@date_to - @date_from)AS INT)))) OrderDate ,
  10 + ABS(CHECKSUM(NEWID())) % 10000 AS Amount 
FROM dbo.GetNums(10000000)
GO
 
UPDATE dbo.Orders SET OrderDate='20170101' WHERE CustomerId < 100000;
UPDATE STATISTICS dbo.Orders ix1;
SELECT count(1) FROM dbo.Orders

SELECT * FROM dbo.Orders WHERE OrderDate = '20140330';
DECLARE @d DATE = '20140330';
SELECT * FROM dbo.Orders WHERE OrderDate = @d;
GO


--choose the Discard results after execution option
SELECT * FROM dbo.Orders WHERE OrderDate =  '20170101';
DECLARE @d DATE = '20170101';
SELECT * FROM dbo.Orders WHERE OrderDate =  @d;

DBCC SHOW_STATISTICS ('dbo.Orders','ix1');
select 7.636502E-05 * 10000000

--------------------------------------
-- Greather than operator
--------------------------------------
DECLARE @yesterday DATETIME = DATEADD(day, -1, GETDATE());
SELECT * FROM dbo.Orders WHERE OrderDate >= @yesterday;

--how to solve it? 
--by using literals
SELECT * FROM dbo.Orders WHERE OrderDate >= DATEADD(day, -1, GETDATE());
GO
--by using OPTION(RECOMPILE)
--------------------------------------
DECLARE @yesterday DATETIME = DATEADD(day, -1, GETDATE());
SELECT * FROM dbo.Orders WHERE OrderDate >= @yesterday OPTION(RECOMPILE);
 

 
--select count(*) from dbo.Events

---- Populate the table with 10M rows
--DECLARE @date_from DATETIME = '20210110';
--DECLARE @date_to DATETIME = '20210115';
--DECLARE @number_of_rows INT = 800;
--INSERT INTO dbo.dbo.Events(EventType,EventDate)
--SELECT 1 + ABS(CHECKSUM(NEWID())) % 5 AS eventtype,
--(SELECT(@date_from +(ABS(CAST(CAST( NewID() AS BINARY(8)) AS INT))%CAST((@date_to - @date_from)AS INT)))) AS EventDate
--FROM dbo.GetNums(@number_of_rows)
--GO


--Local variables

SELECT * FROM dbo.Events WHERE EventDate> '20210109'--GETDATE()

declare @now datetime = '20210109' --GETDATE()
SELECT * FROM dbo.Events WHERE EventDate>@now  
go
 
select e1.* from dbo.Events e1
inner   join dbo.Events e2 on e1.id = e2.id+1
WHERE e1.EventDate>'20210109' 

declare @now datetime = '20210109' 
SELECT * FROM dbo.Events e1
inner join dbo.Events e2 on e1.id = e2.id+1
WHERE e1.EventDate>@now  
go

--option (recompile)
SELECT * FROM dbo.Events WHERE EventDate> '20210109'--GETDATE()

declare @now datetime = '20210109' --GETDATE()
SELECT * FROM dbo.Events WHERE EventDate>@now   option (recompile)
go

USE Statistik;
GO

SELECT * FROM B WHERE pid BETWEEN 123000 AND 123100
GO
DECLARE @from INT = 123000,  @to INT = 123100
SELECT * FROM B WHERE pid BETWEEN @from AND @to
GO

select 335305000*sqrt(0.3)*0.3

--option (recompile)

 GO

 SELECT * FROM dbo.Events WHERE EventDate>  GETDATE()

 SELECT * FROM dbo.Events WHERE EventDate> GETDATE()

  DECLARE @d DATETIME = GETDATE()
  SELECT * FROM dbo.Events WHERE EventDate>  @d

 SELECT * FROM dbo.Events WHERE EventDate> @d

 CREATE PROCEDURE dbo.PX @d DATETIME
 AS
 BEGIN
   SELECT * FROM dbo.Events WHERE EventDate>  @d

	SELECT * FROM dbo.Events WHERE EventDate> @d

 END
 GO
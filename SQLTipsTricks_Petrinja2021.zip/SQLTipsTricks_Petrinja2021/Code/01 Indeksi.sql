use TestDb
go
SELECT * FROM dbo.Events WHERE EventDate>'20210109'   
SELECT * FROM dbo.Events WHERE EventDate>'20120109' 

 SELECT * FROM dbo.Events WHERE EventDate>'20120109' 
 SELECT * FROM dbo.Events with (index(ix1)) WHERE EventDate>'20120109' option(recompile)
 

SELECT * FROM dbo.Events WHERE EventDate>'20201218' option(recompile)
SELECT * FROM dbo.Events WHERE EventDate>'20201217' option(recompile)

SELECT * FROM dbo.Events WHERE EventDate>'20201217' option(recompile)
SELECT * FROM dbo.Events with (index(ix1)) WHERE EventDate>'20201217' option(recompile)
 --select 770016*100.0/10750800


SELECT id,EventDate FROM dbo.Events WHERE EventDate>'20201218' option(recompile)
SELECT id,EventDate FROM dbo.Events WHERE EventDate>'20201217' option(recompile)

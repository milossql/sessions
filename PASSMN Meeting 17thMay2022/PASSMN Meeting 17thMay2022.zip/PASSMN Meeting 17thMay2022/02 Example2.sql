-------------------------------------------------------------------------------------
-- Session: Parameter Sniffing with SQL Server Stored Procedures  
-- Milos Radivojevic, Data Platform MVP, Entain, Austria
-- E: milos.radivojevic@chello.at
-------------------------------------------------------------------------------------

USE PS;
GO
--another example
CREATE OR ALTER PROCEDURE dbo.GetOrdersAggregationsForDates
@From DATETIME, @To DATETIME
AS
BEGIN
    SELECT SUM(Amount * 1.0),
           COUNT(*)
    FROM   dbo.Orders
    WHERE  OrderDate >= @From
           AND OrderDate < @To;
END
GO
ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE;
GO
EXEC dbo.GetOrdersAggregationsForDates '20210101','20210102';
EXEC dbo.GetOrdersAggregationsForDates '20200101','20210201';
EXEC dbo.GetOrdersAggregationsForDates '20130101','20210201';
GO

CREATE OR ALTER PROCEDURE dbo.GetOrdersAggregationsForDates
@From DATETIME, @To DATETIME
AS
BEGIN
    SELECT SUM(Amount * 1.0),
           COUNT(*)
    FROM   dbo.Orders
    WHERE  OrderDate >= @From
           AND OrderDate < @To
		  OPTION(RECOMPILE);
END
GO

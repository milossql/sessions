/****************************************************************************/
/*                      SQLKonferenz, Hanau, 12.09.2023                     */
/*                         Author: Milos Radivojevic                        */
/*   Performanceverbesserung von Transact-SQL Abfragen ohne Code�nderung    */
/****************************************************************************/
/*                             Adding an index                              */
/*                                                                          */
/****************************************************************************/


USE PS1;
GO



---------------------------------------
--- Tune this query
---------------------------------------
SELECT MAX(Amount) FROM dbo.Orders;
/*
Table 'Orders'. Scan count 13, logical reads 340769, physical reads 0, page server reads 0, read-ahead reads 0, page server read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob page server reads 0, lob read-ahead reads 0, lob page server read-ahead reads 0.
Table 'Worktable'. Scan count 0, logical reads 0, physical reads 0, page server reads 0, read-ahead reads 0, page server read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob page server reads 0, lob read-ahead reads 0, lob page server read-ahead reads 0.

 SQL Server Execution Times:
   CPU time = 969 ms,  elapsed time = 99 ms.
*/

GO
CREATE OR ALTER PROCEDURE dbo.GetOrders
	@CustomerId INT = NULL, @OrderDate DATETIME = NULL
AS
BEGIN
	SELECT TOP (10) * FROM dbo.Orders
    WHERE (CustomerId = @CustomerId OR @CustomerId IS NULL)
             AND (OrderDate = @OrderDate OR @OrderDate IS NULL)
    ORDER BY Amount DESC
END
GO

SET NOCOUNT ON;
SET STATISTICS IO, TIME ON;
GO

EXEC GetOrders 456;
/*
Table 'Orders'. Scan count 13, logical reads 9161, physical reads 0, page server reads 0, read-ahead reads 0, page server read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob page server reads 0, lob read-ahead reads 0, lob page server read-ahead reads 0.
Table 'Worktable'. Scan count 0, logical reads 0, physical reads 0, page server reads 0, read-ahead reads 0, page server read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob page server reads 0, lob read-ahead reads 0, lob page server read-ahead reads 0.

 SQL Server Execution Times:
   CPU time = 483 ms,  elapsed time = 55 ms.
*/
EXEC GetOrders NULL,'20210401';
/*
Table 'Orders'. Scan count 13, logical reads 20321352, physical reads 0, page server reads 0, read-ahead reads 0, page server read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob page server reads 0, lob read-ahead reads 0, lob page server read-ahead reads 0.
Table 'Worktable'. Scan count 0, logical reads 0, physical reads 0, page server reads 0, read-ahead reads 0, page server read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob page server reads 0, lob read-ahead reads 0, lob page server read-ahead reads 0.

 SQL Server Execution Times:
   CPU time = 18278 ms,  elapsed time = 1646 ms.
*/

GO

EXEC GetOrders NULL,'20210401';
/*
Table 'Orders'. Scan count 13, logical reads 11302, physical reads 0, page server reads 0, read-ahead reads 0, page server read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob page server reads 0, lob read-ahead reads 0, lob page server read-ahead reads 0.
Table 'Worktable'. Scan count 0, logical reads 0, physical reads 0, page server reads 0, read-ahead reads 0, page server read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob page server reads 0, lob read-ahead reads 0, lob page server read-ahead reads 0.

 SQL Server Execution Times:
   CPU time = 435 ms,  elapsed time = 53 ms.
*/

EXEC GetOrders 456;
/*
Table 'Orders'. Scan count 13, logical reads 20011294, physical reads 0, page server reads 0, read-ahead reads 0, page server read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob page server reads 0, lob read-ahead reads 0, lob page server read-ahead reads 0.
Table 'Worktable'. Scan count 0, logical reads 0, physical reads 0, page server reads 0, read-ahead reads 0, page server read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob page server reads 0, lob read-ahead reads 0, lob page server read-ahead reads 0.

 SQL Server Execution Times:
   CPU time = 17159 ms,  elapsed time = 1473 ms.
*/
GO

CREATE OR ALTER PROCEDURE dbo.GetOrders
	@CustomerId INT = NULL, @OrderDate DATETIME = NULL
AS
BEGIN
	SELECT TOP (10) * FROM dbo.Orders
    WHERE (CustomerId = @CustomerId OR @CustomerId IS NULL)
             AND (OrderDate = @OrderDate OR @OrderDate IS NULL)
    ORDER BY Amount DESC
	OPTION(OPTIMIZE FOR UNKNOWN)
END
GO

EXEC GetOrders 456;
/*
Table 'Orders'. Scan count 13, logical reads 340769, physical reads 0, page server reads 0, read-ahead reads 0, page server read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob page server reads 0, lob read-ahead reads 0, lob page server read-ahead reads 0.

 SQL Server Execution Times:
   CPU time = 842 ms,  elapsed time = 91 ms.
*/
EXEC GetOrders NULL,'20210401';
/*
Table 'Orders'. Scan count 13, logical reads 340769, physical reads 0, page server reads 0, read-ahead reads 0, page server read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob page server reads 0, lob read-ahead reads 0, lob page server read-ahead reads 0.

 SQL Server Execution Times:
   CPU time = 1219 ms,  elapsed time = 102 ms.
*/


---------------------------------------
--- Tune this query
---------------------------------------
SELECT MAX(Amount) FROM dbo.Orders;
/*
Table 'Orders'. Scan count 13, logical reads 340769, physical reads 0, page server reads 0, read-ahead reads 0, page server read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob page server reads 0, lob read-ahead reads 0, lob page server read-ahead reads 0.
Table 'Worktable'. Scan count 0, logical reads 0, physical reads 0, page server reads 0, read-ahead reads 0, page server read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob page server reads 0, lob read-ahead reads 0, lob page server read-ahead reads 0.

 SQL Server Execution Times:
   CPU time = 969 ms,  elapsed time = 99 ms.
*/

--add an index
CREATE INDEX ix0 ON Orders(Amount);
GO
SELECT MAX(Amount) FROM dbo.Orders;
/*
Table 'Orders'. Scan count 1, logical reads 3, physical reads 0, page server reads 0, read-ahead reads 0, page server read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob page server reads 0, lob read-ahead reads 0, lob page server read-ahead reads 0.

 SQL Server Execution Times:
   CPU time = 0 ms,  elapsed time = 0 ms.
*/

--but

EXEC GetOrders 456;
/*
Table 'Orders'. Scan count 1, logical reads 1052561, physical reads 0, page server reads 0, read-ahead reads 0, page server read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob page server reads 0, lob read-ahead reads 0, lob page server read-ahead reads 0.

 SQL Server Execution Times:
   CPU time = 453 ms,  elapsed time = 448 ms.
*/
EXEC GetOrders NULL,'20210401';
/*
Table 'Orders'. Scan count 1, logical reads 20321193, physical reads 0, page server reads 0, read-ahead reads 0, page server read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob page server reads 0, lob read-ahead reads 0, lob page server read-ahead reads 0.

 SQL Server Execution Times:
   CPU time = 8437 ms,  elapsed time = 8432 ms.

*/

--cleanup
DROP INDEX ix0 ON Orders;

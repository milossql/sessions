
---------------------------------------------------------------------
-- Settings
---------------------------------------------------------------------
SET STATISTICS IO ON; --include IO statistics
SET NOCOUNT ON; --do not show affected rows info
--INCLUDE ACTUAL EXECUTION PLAN
GO
USE AdventureWorks2019
GO

-- Create and populate tables dbo.Contacts
 
DROP TABLE IF EXISTS dbo.Contacts;
GO

SELECT * INTO dbo.Contacts FROM Person.Person;
--Create clustered index on ContactID and nonclustered on the LastName
CREATE UNIQUE CLUSTERED INDEX PK_Contacts ON dbo.Contacts(BusinessEntityID);
GO
CREATE NONCLUSTERED INDEX IX33 ON dbo.Contacts(LastName);
GO


---------------------------------------------------------------------
--Data Type Conversions
---------------------------------------------------------------------

-- 3.1 nvarchar column and varchar argument - NOTHING happens
SELECT FirstName, LastName FROM dbo.Contacts WHERE LastName ='Atkinson';
GO
SELECT FirstName, LastName FROM dbo.Contacts WHERE LastName =N'Atkinson';
--Result: 50% : 50% 

--Add new column with VARCHAR type, update and index it
ALTER TABLE dbo.Contacts ADD LastName_Varchar VARCHAR(50);
GO
UPDATE dbo.Contacts SET LastName_Varchar = LastName;
GO
CREATE INDEX IX44 ON dbo.Contacts(LastName_Varchar);
GO

--VARCHAR column and NVARCHAR argument - CONVERSION needed
SELECT FirstName,LastName_Varchar FROM dbo.Contacts WHERE LastName_Varchar = 'Atkinson';
SELECT FirstName,LastName_Varchar FROM dbo.Contacts WHERE LastName_Varchar = N'Atkinson';


--Result: 5% : 95% (Conversion overhead is significant; non-unicode will be converted to Unicode)
--Logical Reads: 5 vs. 54

--Equivalent to an explicit conversion
SELECT FirstName, LastName_Varchar FROM dbo.Contacts WHERE LastName_Varchar = N'Atkinson';
SELECT FirstName, LastName_Varchar FROM dbo.Contacts WHERE CONVERT(NVARCHAR(50),LastName_Varchar)= N'Atkinson';


--Solution: Use the column data type for argument too, or explicitely convert the argument data type to the column data type
SELECT FirstName, LastName_Varchar FROM dbo.Contacts WHERE LastName_Varchar ='Atkinson';
SELECT FirstName, LastName_Varchar FROM dbo.Contacts WHERE LastName_Varchar = CONVERT(VARCHAR(50),N'Atkinson')

--Wrong estimation:
SELECT FirstName, LastName_Varchar FROM dbo.Contacts WHERE LastName_Varchar LIKE 'A%';
SELECT FirstName, LastName_Varchar FROM dbo.Contacts WHERE LastName_Varchar LIKE N'A%';

--Clean up
DROP INDEX IX44 ON dbo.Contacts;
ALTER TABLE dbo.Contacts DROP COLUMN LastName_Varchar;
GO

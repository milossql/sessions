USE NewDB;
GO
--Create sample table 
IF OBJECT_ID('dbo.Customers', 'U') IS NOT NULL DROP TABLE dbo.Customers;
GO
CREATE TABLE dbo.Customers(
	id INT NOT NULL,
	custname NVARCHAR(50) NOT NULL,
 CONSTRAINT PK_Customers PRIMARY KEY CLUSTERED (id ASC)
)
GO

IF OBJECT_ID('dbo.NextPayment', 'U') IS NOT NULL DROP TABLE dbo.NextPayment;
GO
CREATE TABLE dbo.NextPayment(
	custid INT NOT NULL,
	amount MONEY NOT NULL,
	details NVARCHAR(100) NULL
)
GO
CREATE CLUSTERED INDEX ixc ON dbo.NextPayment(custid)
GO

--populate the Customers table
INSERT INTO dbo.Customers(id, custname)
SELECT --1 + ABS(CHECKSUM(NEWID())) % 100000 AS custid,
n, 'cust' + CAST(n AS NVARCHAR)
FROM dbo.GetNums(10000)
GO

 

--populate the NextPayment table
INSERT INTO dbo.NextPayment(custid, amount, details)
SELECT --1 + ABS(CHECKSUM(NEWID())) % 100000 AS custid,
n, 
1 + ABS(CHECKSUM(NEWID())) % 1000 AS amount,
'details'
FROM dbo.GetNums(9999)
GO
INSERT INTO dbo.NextPayment(custid, amount, details) VALUES(10000, 10000000, N''),(10000, 5, N'');
GO


SELECT c.id, c.custname, 
(
SELECT  p.amount
FROM dbo.NextPayment p WHERE p.custid = c.id
)
FROM dbo.Customers c


--
SELECT c.id, c.custname, 
(
SELECT TOP 1 p.amount
FROM dbo.NextPayment p WHERE p.custid = c.id
)
FROM dbo.Customers c

SELECT * FROM dbo.NextPayment WHERE custid = 10000
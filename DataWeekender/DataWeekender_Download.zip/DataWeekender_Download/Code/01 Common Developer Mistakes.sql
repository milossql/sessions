
USE AdventureWorks2019;
-----------------------------------------------
--Order of JOINS
-----------------------------------------------
SELECT c.CustomerID, soh.SalesOrderID
FROM Sales.Customer c 
LEFT JOIN Sales.SalesOrderHeader soh ON c.CustomerID = soh.CustomerID 
WHERE c.CustomerID IN (1, 11000);

SELECT c.CustomerID, soh.SalesOrderID, sod.SalesOrderDetailID
FROM Sales.Customer c 
LEFT JOIN Sales.SalesOrderHeader soh ON c.CustomerID = soh.CustomerID 
 JOIN Sales.SalesOrderDetail sod ON soh.SalesOrderID = sod.SalesOrderID
WHERE c.CustomerID IN (1, 11000);

SELECT c.CustomerID, soh.SalesOrderID, sod.SalesOrderDetailID
FROM Sales.Customer c 
LEFT JOIN Sales.SalesOrderHeader soh 
INNER JOIN Sales.SalesOrderDetail sod 
	ON soh.SalesOrderID = sod.SalesOrderID
	ON c.CustomerID = soh.CustomerID 
WHERE c.CustomerID IN (1, 11000);

--------------------------------------------
--OUTER JOINS - Placement of predicates
--------------------------------------------

SELECT c.CustomerID, soh.SalesOrderID 
FROM Sales.Customer c 
LEFT JOIN Sales.SalesOrderHeader soh ON c.CustomerID = soh.CustomerID   
WHERE c.CustomerID = 1;

SELECT c.CustomerID, soh.SalesOrderID 
FROM Sales.Customer c 
LEFT JOIN Sales.SalesOrderHeader soh ON c.CustomerID = soh.CustomerID  
AND c.CustomerID = 1;

SELECT c.CustomerID, soh.SalesOrderID 
FROM Sales.Customer c 
LEFT JOIN Sales.SalesOrderHeader soh ON c.CustomerID = soh.CustomerID   
WHERE c.CustomerID = 1 AND soh.OrderDate>'20000101';

SELECT c.CustomerID, soh.SalesOrderID 
FROM Sales.Customer c 
LEFT OUTER JOIN Sales.SalesOrderHeader soh ON c.CustomerID = soh.CustomerID 
AND soh.OrderDate>'20000101'
WHERE c.CustomerID = 1;


--------------------------------------------
--Predicate evaluation order
--------------------------------------------
--TASK: Get all records from the Address table for the city Port Orchard and ZIP 98366
--PostalCode is alphanumeric
--This works
SELECT * FROM Person.Address 
WHERE City = 'Port Orchard' AND PostalCode = 98366;
--(90 row(s) affected)

--This one doesn't work
SELECT * FROM Person.Address 
WHERE City LIKE 'Port Orchard' AND  PostalCode =98366;
--Conversion failed when converting the nvarchar value 'K4B 1S2' to data type int.
--There is no guarantee that operation against the City column will be evaluated first!

 --This one works regardless the evaluation order
SELECT * FROM Person.Address 
WHERE City LIKE 'Port Orchard' AND  CASE WHEN PostalCode NOT LIKE '%[^0-9]%' THEN PostalCode END = 98366;
--(90 row(s) affected)

--This one works regardless the evaluation order (let's remove the City column)
SELECT * FROM Person.Address 
WHERE  CASE WHEN PostalCode NOT LIKE '%[^0-9]%' THEN PostalCode END = 98366;
--(90 row(s) affected)


-----------------------------------------------
--NULL and NOT IN
------------------------------------------------

--Create a help table
USE AdventureWorks2019
GO
IF OBJECT_ID('dbo.Color', 'U') IS NOT NULL DROP TABLE dbo.Color;
GO
CREATE TABLE dbo.Color (id int, name varchar(30) not null)
GO
INSERT INTO dbo.Color(id,name) VALUES(1,'Black'),(2,'White'), (3,'Purple')
GO
SELECT * FROM dbo.Color
/*Results
id          name
----------- ------------------------------
1           Black
2           White
3           Purple						*/
------------------------------------------------------------------------------------------------------------
--TASK: List of colors in which there is no products in the Production.Product table
------------------------------------------------------------------------------------------------------------
--NOT IN approach (wrong)
SELECT * FROM AdventureWorks2019.Production.Product
WHERE Color='Purple'

SELECT * FROM dbo.Color 
WHERE name NOT IN (SELECT Color FROM AdventureWorks2019.Production.Product)
UNION ALL
SELECT * FROM dbo.Color 
WHERE name   IN (SELECT Color FROM AdventureWorks2019.Production.Product)

/*Results
id          name
----------- ------------------------------					

(0 row(s) affected)							*/

--The list is empty but it should be shown "Purple"!

--IN works correct
SELECT * FROM dbo.Color 
WHERE name IN (NULL,'Black','Blue')
/*Results
id          name
----------- ------------------------------
1           Black							*/

--But NOT IN doesn't due to three value logic
SELECT * FROM dbo.Color 
WHERE name NOT IN (NULL,'Black','Blue')
/*Results
id          name
----------- ------------------------------					

(0 row(s) affected)							*/

--Solution is NOT EXISTS approach 
SELECT *
FROM dbo.Color c
WHERE NOT EXISTS(SELECT 1 FROM AdventureWorks2019.Production.Product p
WHERE p.Color = c.name)                     
GO
/*Results
id          name
----------- ------------------------------
3           Purple						*/


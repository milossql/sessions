
USE YourDatabaseName;
GO
DROP TABLE IF EXISTS dbo.Orders;
GO
CREATE TABLE dbo.Orders(
id INT IDENTITY(1,1) NOT NULL,
custid INT NOT NULL,
orderdate DATETIME NOT NULL,
amount MONEY NOT NULL,
CONSTRAINT PK_Orders PRIMARY KEY CLUSTERED (id ASC)
);
GO
 
 -- Populate the order table with 1M rows for 2014
DECLARE @date_from DATETIME = '20130101';
DECLARE @date_to DATETIME = '20181104';
DECLARE @number_of_rows INT = 1000000;
INSERT INTO dbo.Orders(custid,orderdate,amount)
SELECT 1 + ABS(CHECKSUM(NEWID())) % 40000 AS custid,
(SELECT(@date_from +(ABS(CAST(CAST( NewID() AS BINARY(8)) AS INT))%CAST((@date_to - @date_from)AS INT)))) AS orderdate,
1 + ABS(CHECKSUM(NEWID())) % 1000 AS amount
FROM dbo.GetNums(@number_of_rows)
GO

CREATE INDEX ix1 on Orders(orderdate)
GO
DECLARE @yesterday DATETIME = DATEADD(day, -1, GETDATE())
SELECT * FROM Orders WHERE orderdate >= @yesterday
--OPTION (RECOMPILE)
GO
 
SELECT * FROM Orders WHERE orderdate >= DATEADD(day, -1, GETDATE())

 
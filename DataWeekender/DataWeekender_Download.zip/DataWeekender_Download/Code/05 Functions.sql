

---------------------------------------------------------------------
-- Settings
---------------------------------------------------------------------
SET STATISTICS IO ON; --include IO statistics
SET NOCOUNT ON; --do not show affected rows info
--INCLUDE ACTUAL EXECUTION PLAN
GO
USE AdventureWorks2019
GO
-- Create and populate tables dbo.Orders
DROP TABLE IF EXISTS dbo.Orders;
GO
SELECT * INTO dbo.Orders FROM Sales.SalesOrderHeader;
--Create clustered index on SalesOrderID
CREATE UNIQUE CLUSTERED INDEX PK_Orders ON dbo.Orders(SalesOrderID);
GO

---------------------------------------------------------------------
--YEAR Function vs. Arithemtical Equivalent (Compare the queries)
---------------------------------------------------------------------

SELECT * FROM dbo.Orders WHERE YEAR(OrderDate) = 2011;
GO
SELECT * FROM dbo.Orders WHERE OrderDate >= '20110101' AND OrderDate < '20120101';
-- Result: 50% : 50% (There is no index on the OrderDate column)
GO
--Create a nonclustered index on the column OrderDate
CREATE NONCLUSTERED INDEX IX22 ON dbo.Orders(OrderDate);
GO

--Let's compare again:
SELECT * FROM dbo.Orders WHERE YEAR(OrderDate) = 2011;
GO
SELECT * FROM dbo.Orders WHERE OrderDate >= '20110101' AND OrderDate < '20120101';
GO
--Result: 50% : 50% (Query is not selective enough!)

--Let's update one order to today's date
UPDATE dbo.Orders 
SET OrderDate = GETDATE(),
	DueDate= DATEADD(day,1,GETDATE()),
	ShipDate= DATEADD(day,1,GETDATE()) 
WHERE SalesOrderID =(SELECT MAX(SalesOrderID) FROM dbo.Orders);

--and check again
SELECT * FROM dbo.Orders WHERE YEAR(OrderDate) = 2018;
GO
SELECT * FROM dbo.Orders WHERE OrderDate >= '20180101' AND OrderDate < '20190101';
GO
--Result: 94% : 6% (The second query performs better)

--Let's take only two columns
SELECT SalesOrderID,OrderDate FROM dbo.Orders WHERE YEAR(OrderDate) = 2011;
GO
SELECT SalesOrderID,OrderDate FROM dbo.Orders WHERE OrderDate >= '20110101' AND OrderDate < '20120101';
--Result: 68% : 32% (The second query performs better even if the query is not selective enough)
use Statistik
select  id, pid from A where pid = 77765

select  id, pid from A where ABS(pid) = 77765
---------------------------------------------------------------------
--SUBSTRING Function vs. LIKE Operator
---------------------------------------------------------------------

-- Create and populate tables dbo.Orders
DROP TABLE IF EXISTS dbo.Contacts;
GO
SELECT BusinessEntityID, PersonType, NameStyle, Title, FirstName, MiddleName, LastName, Suffix
 INTO dbo.Contacts FROM Person.Person;
--Create clustered index on ContactID and nonclustered on the LastName
CREATE UNIQUE CLUSTERED INDEX PK_Contacts ON dbo.Contacts(BusinessEntityID);
GO
CREATE NONCLUSTERED INDEX IX33 ON dbo.Contacts(LastName);
GO

--Compare the queries (low selectivity)
SELECT * FROM dbo.Contacts WHERE SUBSTRING(LastName, 1, 1)='A'; 
GO
SELECT * FROM dbo.Contacts WHERE LastName LIKE 'A%';
--Result: 50% : 50% (Query is not selective enough)

--Compare the queries (high selectivity)
SELECT * FROM dbo.Contacts WHERE SUBSTRING(LastName, 1, 4)='Atki'; 
GO
SELECT * FROM dbo.Contacts WHERE LastName LIKE 'Atki%'; 
--Result: 92% : 8% (The second query performs better => it is SARGeable, the first query uses a function)

--Low selectivity, but covered query
SELECT LastName,BusinessEntityID FROM dbo.Contacts WHERE SUBSTRING(LastName, 1, 1)='A'; 
GO
SELECT LastName,BusinessEntityID FROM dbo.Contacts WHERE LastName LIKE 'A%';
--Result: 93% : 7% 

--UPPER Function
---------------------------------------------------------------------
SELECT * FROM dbo.Contacts WHERE UPPER(LastName)='OKELBERRY';
GO
SELECT * FROM dbo.Contacts WHERE  LastName ='OKELBERRY';
--Result: 91% : 9% (The UPPER function will be evaluated for each last name. 
--When database is case insensitive, it does not make sense to use the UPPER and LOWER functions)

--Drop Index
--DROP INDEX IX_Contacts_LastName ON dbo.Contacts;
--GO

 
 
---------------------------------------------------------------------
--Arithmetical Operation in the WHERE clause
---------------------------------------------------------------------
 
--Product operator prevents usage of clustered index seek
SELECT * FROM dbo.Contacts WHERE BusinessEntityID*2=10000;
GO
SELECT * FROM dbo.Contacts  WHERE BusinessEntityID =10000/2;
--Result: 96% : 4% (The first query multiply each BusinessEntityID with 2 and then compare it against 10000)

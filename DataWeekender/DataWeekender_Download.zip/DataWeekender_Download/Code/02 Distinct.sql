SELECT DISTINCT
	c.CustomerID, soh.SalesOrderID, soh.OrderDate, soh.DueDate, soh.AccountNumber,
	soh.BillToAddressID, soh.CreditCardID, soh.SubTotal
FROM Sales.Customer c 
INNER JOIN Sales.SalesOrderHeader soh 
INNER JOIN Sales.SalesOrderDetail sod ON sod.SalesOrderID = soh.SalesOrderID
ON c.CustomerID = soh.CustomerID 
WHERE c.CustomerID IN (1, 11000);
GO
SELECT 
	c.CustomerID, soh.SalesOrderID, soh.OrderDate, soh.DueDate, soh.AccountNumber,
	soh.BillToAddressID, soh.CreditCardID, soh.SubTotal
FROM Sales.Customer c 
INNER JOIN Sales.SalesOrderHeader soh 
ON c.CustomerID = soh.CustomerID 
--WHERE c.CustomerID IN (1, 11000);